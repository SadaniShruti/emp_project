<?php
require "config.php";
	if(isset($_POST['Name']))
	{
		$nm=$_POST['Name'];
		$mail=$_POST['email'];
		$brth=$_POST['birthday'];
		$gender=$_POST['gender'];
		$cno=$_POST['contact'];
		$add=$_POST['address'];
		$dept=$_POST['dept'];
		$degree=$_POST['degree'];
		$salary=$_POST['salary'];
		
		$files = $_FILES['file'];
		$filename = $files['name'];
		$filrerror = $files['error'];
		$filetemp = $files['tmp_name'];
		$fileext = explode('.', $filename);
		$filecheck = strtolower(end($fileext));
		$fileextstored = array('png' , 'jpg' , 'jpeg');

if(in_array($filecheck, $fileextstored)){

    $destinationfile = $filename;
    move_uploaded_file($filetemp, $destinationfile);


			$sql = "INSERT INTO `add_emp`(`full_name`,`email`,`password`,`birthdate`,`gender`,`contact_no`,`address`,`department`,`degree`,`salary`,`pic`) VALUES ('$nm','$mail','1234','$brth','$gender','$cno','$add','$dept','$degree','$salary','$destinationfile')";
			$result = mysqli_query($con, $sql);
			$last_id = $con->insert_id;

			$sqlS = "INSERT INTO `salary`(`id`, `base`, `bonus`, `total`) VALUES ('$last_id','$salary',0,'$salary')";
			$salaryQ = mysqli_query($con, $sqlS);
			$rank = mysqli_query($con, "INSERT INTO `rank`(`eid`) VALUES ('$last_id')");
	
			if($result == 1)
			{
				echo ("<SCRIPT LANGUAGE='JavaScript'>
				window.alert('Succesfully Registered')
				window.location.href='viewemp.php';
				</SCRIPT>");
				//header("Location: ..//aloginwel.php");
			}
}
				else
			{
				echo ("<SCRIPT LANGUAGE='JavaScript'>
				window.alert('Failed to Registere')
				window.location.href='javascript:history.go(-1)';
				</SCRIPT>");
			}


		{
			$sql = "INSERT INTO `add_emp`(`full_name`,`email`, `password`, `birthday`, `gender`, `contact`,`address`, `dept`, `degree`,`pic`) VALUES ('$nm','$mail','1234','$brth','$gender','$cno','$add','$dept','$degree','images/no.jpg')";
			$result = mysqli_query($con, $sql);
			$last_id = $con->insert_id;

			//$sqlS = "INSERT INTO `salary`(`id`, `base`, `bonus`, `total`) VALUES ('$last_id','$salary',0,'$salary')";
			//$salaryQ = mysqli_query($con, $sqlS);
			//$rank = mysqli_query($con, "INSERT INTO `rank`(`eid`) VALUES ('$last_id')");

			if(($result) == 1)
			{
				echo ("<SCRIPT LANGUAGE='JavaScript'>
				window.alert('Succesfully Registered')
				window.location.href='viewemp.php';
				</SCRIPT>");
				header("Location: aloginwel.php");
			}

			// else{
			//     echo ("<SCRIPT LANGUAGE='JavaScript'>
			//     window.alert('Failed to Registere')
			//     window.location.href='javascript:history.go(-1)';
			//     </SCRIPT>");
			// }
		}

	}




	
?>
	<script>
		imgInp.onchange = evt =>
			{
				const[file] = imgInp.files
				if(file)
				{
					blah.src=URL.createObjectURL(file)
				}
			}
	</script>
	
<!DOCTYPE html>
<html>

<head>
   

    <!-- Title Page-->
    <title>Add Employee | Employee Management System</title>
	
    <!-- Icons font CSS-->
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <!-- Font special for pages-->
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">

    <!-- Vendor CSS-->
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/datepicker/daterangepicker.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="css/main.css" rel="stylesheet" media="all">
	 <link href="css/styleapply.css" rel="stylesheet" media="all">
	 <link href="css/styleprofile.css" rel="stylesheet" media="all">
</head>

<body>
    <header>
        <nav>
            <h1>EMS</h1>
            <ul id="navli">
                <li><a class="homeblack" href="aloginwel.php">HOME</a></li>
                <li><a class="homered" href="addemp.php">Add Employee</a></li>
                <li><a class="homeblack" href="viewemp.php">View Employee</a></li>
                <li><a class="homeblack" href="assign.php">Assign Project</a></li>
                <li><a class="homeblack" href="assignproject.php">Project Status</a></li>
                <li><a class="homeblack" href="salaryemp.php">Salary Table</a></li> 
                <li><a class="homeblack" href="empleave.php">Employee Leave</a></li>
                <li><a class="homeblack" href="alogin.php">Log Out</a></li>
            </ul>
        </nav>
    </header>
    
    <div class="divider"></div>




    <div class="page-wrapper bg-blue p-t-100 p-b-100 font-robo">
        <div class="wrapper wrapper--w680">
            <div class="card card-1">
                <div class="card-heading"></div>
                <div class="card-body">
                    <h2 class="title">Add Employee</h2>
					
                    <form action="addemp.php" method="POST" enctype="multipart/form-data">
					

                        

                        <div>
                            <div class="col-1">
                                <div class="input-group">
                                     <input class="input--style-1" type="text" placeholder="Full Name" name="Name" required="required">
                                </div>
                            </div>
                           
                       <div class="input-group">
                            <input class="input--style-1" type="email" placeholder="Email" name="email" required="required">
                        </div>
						
						
                        <p>Birthday</p>
                        <div>
                            <div class="col-2">
                                <div class="input-group">
                                    <input class="input--style-1" type="date" placeholder="BIRTHDATE" name="birthday" required="required">
                                   
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">
                                    <div class="rs-select2 js-select-simple select--no-search">
                                        <select name="gender">
                                            <option disabled="disabled" selected="selected">GENDER</option>
                                            <option value="Male">Male</option>
                                            <option value="Female">Female</option>
                                            <option value="Other">Other</option>
                                        </select>
                                        <div class="select-dropdown"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="input-group">
                            <input class="input--style-1" type="number" placeholder="Contact Number" name="contact" required="required" >
                        </div>
                         <div class="input-group">
                            <input class="input--style-1" type="text" placeholder="Address" name="address" required="required">
                        </div>

                        <div class="input-group">
                            <input class="input--style-1" type="text" placeholder="Department" name="dept" required="required">
                        </div>

                        <div class="input-group">
                            <input class="input--style-1" type="text" placeholder="Degree" name="degree" required="required">
                        </div>

                        <div class="input-group">
                            <input class="input--style-1" type="number" placeholder="Salary" name="salary">
                        </div>

						<input type="file" name="file" placeholder="file" class="form-control" id="imgInp" accept=".png,.jpg,.jpeg"></br>
						

                        <div class="p-t-20">
                            <button class="btn btn--radius btn--green" type="submit">Submit</button>
						
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Jquery JS-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <!-- Vendor JS-->
    <script src="vendor/select2/select2.min.js"></script>
    <script src="vendor/datepicker/moment.min.js"></script>
    <script src="vendor/datepicker/daterangepicker.js"></script>

    <!-- Main JS-->
    <script src="js/global.js"></script>

</body>

</html>
<!-- end document-->
