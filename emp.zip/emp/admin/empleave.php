<?php
require "config.php";

if(isset($_GET['type']) && $_GET['type']=='delete' && isset($_GET['id'])){
		$id=mysqli_real_escape_string($con,$_GET['id']);
		mysqli_query($con,"delete from `employee_leave` where id ='$id'");
}
$res=mysqli_query($con,"Select add_emp.id, employee_leave.start, employee_leave.end, employee_leave.reason, employee_leave.status, employee_leave.token From add_emp, employee_leave Where add_emp.id = employee_leave.id order by employee_leave.token");

if(isset($_GET['type']) && $_GET['type']=='update' && isset($_GET['id'])){
	$id=mysqli_real_escape_string($con,$_GET['id']);
	$status=mysqli_real_escape_string($con,$_GET['status']);
	mysqli_query($con,"update `employee_leave` set status='$status' where id='$id'");
}

	$sql="SELECT * FROM `employee_leave` order by id desc";
{
	$id=['eid'];
	
}
$res=mysqli_query($con,$sql);

?>

<html>
<head>
	<title>Employee Leave | Admin Panel | Employee Management System</title>
	<link rel="stylesheet" type="text/css" href="styleview.css">
</head>
<body>
	
	<header>
		<nav>
			<h1>EMS</h1>
			<ul id="navli">
				<li><a class="homeblack" href="aloginwel.php">HOME</a></li>
				
				<li><a class="homeblack" href="addemp.php">Add Employee</a></li>
				<li><a class="homeblack" href="viewemp.php">View Employee</a></li>
				<li><a class="homeblack" href="assign.php">Assign Project</a></li>
				<li><a class="homeblack" href="assignproject.php">Project Status</a></li>
				<li><a class="homeblack" href="salaryemp.php">Salary Table</a></li>
				<li><a class="homered" href="empleave.php">Employee Leave</a></li>
				<li><a class="homeblack" href="alogin.php">Log Out</a></li>
			</ul>
		</nav>
	</header>
	 
	<div class="divider"></div>
	<div id="divimg">
	<div class="orders">
	<div class="row">
	<div class="col-xl-12">
	<div class="card">
	<div class="card-body">
	
	</div>
	<div class="card-body--">
		<div class="table-status order-table ov-h">
		<table class="table">
		<thead>
			<tr>
				<th>Emp. ID</th>
				<th>token</th>
				<!--<th>Name</th>-->
				<th>Start Date</th>
				<th>End Date</th>
				<th>Reason</th>
				<th>Total days</th>
				<th>Status</th>
				<th>Options</th>
			</tr>
		</thead>
		<tbody>
		<?php 
		$i=1;
		while($row=mysqli_fetch_assoc($res)){?>
		<tr>
			
			<td><?php echo $row['id']?></td>
			<td><?php echo $row['token']?></td>
		<!--	<td><?php echo $row['full_name']?></td>-->
			<td><?php echo $row['start']?></td>
			<td><?php echo $row['end']?></td>
			<td><?php echo $row['reason']?></td>
			<td><?php echo $row['status']?></td>
			<td>
			<?php 
				if($row['status']==1){
					 echo "Applied";
				}if($row['status']==2){
					echo "Approved";
				}if($row['status']==3){
					echo "Rejected";
				}
				?>
				
				<select class="form-control" onchange="update_leave_status('<?php echo $row['id']?>',this.options[this.selectedIndex].value)">
				<option value="">Update status </option>
				<option value="2">Approved</option>
				<option value="3">Rejected</option>
				</select>
				
			</td>
			<td><a class="btn btn-danger" href="empleave.php?id=<?php echo $row['id']; ?>">Delete</a></br></br>
			</tr>
			<?php 
			$i++;
		}
		?>
		<script>
			function update_leave_status(id,select_value){
				window.location.href='empleave.php?id='+id+'&type=update&status='+select_value;
			}
			</script>
		</tbody>
		</table>
		</div>
		</div>
		</div>
		</div>
		</div>
		</div>
		</div>
			
		
</body>
</html>