<?php

include "config.php";
$email = $_POST['mailuid'];
$password = $_POST['pwd'];
$insert="INSERT INTO `alogin` (`id`, `email`, `password`) VALUES (1, 'admin@gmail.com', 'admin')";
$sql = "SELECT * from `alogin` WHERE email = '$email' AND password = '$password'";

//echo "$sql";

$result = mysqli_query($con, $sql);

if(mysqli_num_rows($result) == 1){
	

	//echo ("logged in");
	header("Location: ..//aloginwel.php");
}

else{
	echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Invalid Email or Password')
    window.location.href='javascript:history.go(-1)';
    </SCRIPT>");
}
?>