<!DOCTYPE html>

<html>
<head>
	<title>Employee Management System</title>
	<link href="https://fonts.googleapis.com/css?family=Lobster|Montserrat" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/styleindex.css">
</head>
<body>
	<header>
		<nav>
			<h1>Employee Management System</h1>
			<ul id="navli">
				<li><a class="homered" href="index.php">HOME</a></li>
				<li><a class="homeblack" href="contact.php">CONTACT</a></li>
				<li><a class="homeblack" href="elogin.php">LOG IN</a></li>
			</ul>
		</nav>
	</header>
	
	<div class="divider"></div>
	<div id="divimg">
		
	</div>

	
	<img src="https://img.freepik.com/free-photo/colleagues-working-project-discussing-details_114579-2817.jpg?w=740&t=st=1674290560~exp=1674291160~hmac=5fb288989fa23396f4e21f30b4142cb3582d313c945043f8029e5a7207bd487c" style="float: left; margin-right: 100px; margin-top: 35px; margin-left: 70px">
	

	<div style="margin-top: 150px">
		
		<h1 style="font-family: 'Lobster', cursive; font-weight: 200; font-size: 100px; margin-top: 100px; ">Shruti Corp.</h1>
	</div>
		

	
</body>
</html>