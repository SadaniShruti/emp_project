<?php
	$id = (isset($_GET['id']) ? $_GET['id'] : '');
	require "config.php";
	 $sql1 = "SELECT * FROM `add_emp` where id = '$id'";
	 $result1 = mysqli_query($con, $sql1);
	 $seq = 1;
	 $add_emp = mysqli_fetch_array($result1);
	 $empName = ($add_emp['full_name']);

	$sql = "SELECT * FROM add_emp INNER JOIN rank ON add_emp.id = rank.eid ";
	$sql1 = "SELECT `pname`, `duedate` FROM `project` WHERE eid = $id and status = 'Due'";

	$sql2 ="SELECT * FROM add_emp INNER JOIN employee_leave ON add_emp.id = employee_leave.id";

	$sql3 = "SELECT * FROM `salary` WHERE id = $id";
	$result = mysqli_query($con, $sql);
	$result1 = mysqli_query($con, $sql1);
	$result2 = mysqli_query($con, $sql2);
	$result3 = mysqli_query($con, $sql3);
	
   
	
	
//	echo "$sql";


?>


<html>
<head>
	<title>Employee Panel | Employee Management System</title>
	<link rel="stylesheet" type="text/css" href="styleemplogin.css">
	<link href="https://fonts.googleapis.com/css?family=Lobster|Montserrat" rel="stylesheet">
</head>
<body>
	
	<header>
		<nav>
			<h1>Employee Management System</h1>
			<ul id="navli">
				<li><a class="homered" href="eloginwel.php?id=<?php echo $id?>"">HOME</a></li>
				<li><a class="homeblack" href="myprofile.php?id=<?php echo $id?>"">My Profile</a></li>
				<li><a class="homeblack" href="empproject.php?id=<?php echo $id?>"">My Projects</a></li>
				<li><a class="homeblack" href="applyleave.php?id=<?php echo $id?>"">Apply Leave</a></li>
				<li><a class="homeblack" href="elogin.php">Log Out</a></li>
			</ul>
		</nav>
	</header>
	 
	<div class="divider"></div>
	<div id="divimg">
	<div>
		<!-- <h2>Welcome <?php echo "$empName"; ?> </h2> -->

		    	<h2 style="font-family: 'Montserrat', sans-serif; font-size: 25px; text-align: center;">Empolyee Leaderboard </h2>
    	<table>

			<tr bgcolor="#000">
				<th align = "center">Seq.</th>
				<th align = "center">Emp. ID</th>
				<th align = "center">Name</th>
				<th align = "center">Points</th>
				

			</tr>
			<?php


				$sql = "SELECT * FROM add_emp INNER JOIN employee_leave ON add_emp.id = employee_leave.id";
				$result = mysqli_query($con, $sql);
				while($row=mysqli_fetch_assoc($result)){
				
					
					$date1 = new DateTime($add_emp['start']);
					$date2 = new DateTime($add_emp['end']);
					$interval = $date1->diff($date2);
					$interval = $date1->diff($date2);
?>
		<tr>
			<td><?php echo $seq; ?>	
			<td><?php echo $row['id']?>
			<td><?php echo $row['full_name']?>
			<td><?php echo $row['points']?>
			
			<?php
			$seq+=1;
				}
			
				?>	



			
					
	

		</table>
   
    	<h2 style="font-family: 'Montserrat', sans-serif; font-size: 25px; text-align: center;">Due Projects</h2>
    	

    	<table>

			<tr>
				<th align = "center">Project Name</th>
				<th align = "center">Due Date</th>
				
			</tr>

			

			<?php
				while($row=mysqli_fetch_assoc($result)){
					echo "<tr>";
					
					echo "<td>".$add_emp1['pname']."</td>";
					
					echo "<td>".$add_emp1['duedate']."</td>";
				 }
?>
				
			

		</table>



		<h2 style="font-family: 'Montserrat', sans-serif; font-size: 25px; text-align: center;">Salary Status</h2>
    	

    	<table>

			<tr>
				
				<th align = "center">Base Salary</th>
				<th align = "center">Bonus</th>
				<th align = "center">Total Salary</th>
				
			</tr>

			

			<?php
				
					while($row=mysqli_fetch_assoc($result)){

					echo "<tr>";
					
					
					echo "<td>".$add_emp['base']."</td>";
					echo "<td>".$add_emp['bonus']." %</td>";
					echo "<td>".$add_emp['total']."</td>";
					}
				?>
				

		</table>










		<h2 style="font-family: 'Montserrat', sans-serif; font-size: 25px; text-align: center;">Leave Satus</h2>
    	

    	<table>

			<tr>
				
				<th align = "center">Start Date</th>
				<th align = "center">End Date</th>
				<th align = "center">Total Days</th>
				<th align = "center">Reason</th>
				<th align = "center">Status</th>
			</tr>

			

			<?php
				while($row=mysqli_fetch_assoc($result)){
					$date1 = new DateTime($add_emp['start']);
					$date2 = new DateTime($add_emp['end']);
					$interval = $date1->diff($date2);
					$interval = $date1->diff($date2);

					echo "<tr>";
					
					
					echo "<td>".$add_emp['start']."</td>";
					echo "<td>".$add_emp['end']."</td>";
					echo "<td>".$interval->days."</td>";
					echo "<td>".$add_emp['reason']."</td>";
					echo "<td>".$add_emp['status']."</td>";
				}
				?>
				


				


			

		</table>




   
<br>
<br>
<br>
<br>
<br>







	</div>


		</h2>


		
		
	</div>
</body>
</html>