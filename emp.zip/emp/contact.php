<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
	<link rel="stylesheet" type="text/css" href="contactstyle.css">
	<link href="https://fonts.googleapis.com/css?family=Lobster|Montserrat" rel="stylesheet">
	<!-- Fontawesome CDN Link -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"/>
	<meta charset="UTF-8">
 <!-- <title> Responsive Contact Us Form  | CodingLab </title>-->
	<title>Contact | Employee Management System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<style>
	div.absolute	 {
  position: absolute;
  top: 535px;
  right:0px;
	left:690px;
  width: 200px;
  height: 100px;
  ;
  
	}
	</style>
  </head>
<body>
	<header>
	<nav class="navbar background">
			
  <!-- Creating the list of
			items -->
		<ul class="nav-list">
			<li><a class="active" href="index.php"><i class="fa fa-fw fa-home"></i>Home</a></li>
			
			
		</ul>
		</nav>
		<section class="background firstsection">
		<div class="box-main">
			<div class="firstHalf">	
				<p class="text-big">Contact Us</p>

				<p class="text-small">
					You can Contact Us if you face any problem
				</p>
				
			<div class="email">
                <i class="bi bi-envelope"></i>
                <h4 class="center">Email:</h4>
                <p  class="center">shruti's_corp@gmail.com</p>
              </div>

              <div class="phone">
                <i class="bi bi-phone"></i>
                <h4  class="center">Call:</h4>
                <p  class="center">+91 9865416435</p>
              </div>

				<br>
				<p class="center"
				style="text-decoration:none;
						color:white;">
					Click on the below options to Message us
					
					<ul class="nav-list">
					
					<div class="container">
					<style>
						<div class="container">
  <div class="vertical-center">
						</style>
				<div class="absolute"><li ><a href="contactus.php"><i  class="fa fa-fw fa-envelope"></i>Contact Us</a></li>
				</div>
				</ul>
				</p>

			</div>
		</div>
	</section>
	</body>
</html>

 





	






